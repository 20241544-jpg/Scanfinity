// Wait for DOM
document.addEventListener('DOMContentLoaded', () => {
  // 50 Computer & Technology questions (ready)
  const quizData = [
    { question: "What does CPU stand for?", options: ["Central Processing Unit", "Computer Personal Unit", "Control Processing User", "Central Program Utility"], answer: 0 },
    { question: "Which company created the Windows OS?", options: ["Apple", "Microsoft", "IBM", "Google"], answer: 1 },
    { question: "What does LAN stand for?", options: ["Local Area Network", "Large Access Node", "Linked Application Network", "Logical Array Number"], answer: 0 },
    { question: "Which protocol is used for web browsing?", options: ["FTP", "SMTP", "HTTP", "DNS"], answer: 2 },
    { question: "What does RAM stand for?", options: ["Read Access Memory", "Random Access Memory", "Rapid Action Module", "Remote Array Machine"], answer: 1 },
    { question: "Which company developed the iPhone?", options: ["Samsung", "Apple", "Nokia", "Microsoft"], answer: 1 },
    { question: "What does GPU stand for?", options: ["General Processing Unit", "Graphics Processing Unit", "Global Program Utility", "Graphical Protocol User"], answer: 1 },
    { question: "Which port is used for HTTP?", options: ["20", "21", "80", "443"], answer: 2 },
    { question: "Which one is an input device?", options: ["Monitor", "Printer", "Keyboard", "Speaker"], answer: 2 },
    { question: "What does URL stand for?", options: ["Universal Record Locator", "Uniform Resource Locator", "Unified Remote Link", "User Reference Line"], answer: 1 },
    { question: "Which programming language is mainly used for Android apps?", options: ["Kotlin", "Swift", "C#", "Ruby"], answer: 0 },
    { question: "Which company owns YouTube?", options: ["Meta", "Microsoft", "Google", "Amazon"], answer: 2 },
    { question: "What is the shortcut for copy on Windows?", options: ["Ctrl + C", "Ctrl + X", "Ctrl + V", "Ctrl + Z"], answer: 0 },
    { question: "Which device connects a computer to the internet?", options: ["Router", "Switch", "Hub", "Firewall"], answer: 0 },
    { question: "What is phishing?", options: ["Fishing with a computer", "A cyber attack using fake emails", "A virus type", "A file format"], answer: 1 },
    { question: "Which OS is developed by Apple?", options: ["Linux", "macOS", "Windows", "Android"], answer: 1 },
    { question: "What does HTML stand for?", options: ["Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Mode Line", "Hyper Tool Markup Link"], answer: 0 },
    { question: "Which company created Java?", options: ["Sun Microsystems", "Oracle", "Microsoft", "IBM"], answer: 0 },
    { question: "Which symbol is used for comments in CSS?", options: ["//", "/* */", "#", "<!-- -->"], answer: 1 },
    { question: "What does BIOS stand for?", options: ["Basic Input Output System", "Binary Integrated Operating System", "Base Input Output Service", "Basic Internal OS"], answer: 0 },
    { question: "Which device stores permanent data?", options: ["RAM", "Cache", "Hard Drive", "Registers"], answer: 2 },
    { question: "What is 1 Terabyte equal to?", options: ["1024 MB", "1024 GB", "100 GB", "500 MB"], answer: 1 },
    { question: "Which of these is NOT a programming language?", options: ["Python", "C++", "Oracle", "Java"], answer: 2 },
    { question: "Which company owns Instagram?", options: ["Meta", "Google", "Snapchat", "Twitter"], answer: 0 },
    { question: "What does DNS stand for?", options: ["Domain Name System", "Data Network Service", "Direct Number Server", "Digital Network System"], answer: 0 },
    { question: "Which is the first web browser?", options: ["Internet Explorer", "Mosaic", "Netscape", "Opera"], answer: 1 },
    { question: "Which file extension is for compressed files?", options: [".docx", ".zip", ".mp4", ".exe"], answer: 1 },
    { question: "What is the main function of an operating system?", options: ["Run apps", "Control hardware & software", "Play music", "Store data"], answer: 1 },
    { question: "Which shortcut is paste in Windows?", options: ["Ctrl + X", "Ctrl + V", "Ctrl + C", "Ctrl + Z"], answer: 1 },
    { question: "Which one is a cloud storage service?", options: ["OneDrive", "Chrome", "Photoshop", "Visual Studio"], answer: 0 },
    { question: "Which company developed the Android OS?", options: ["Google", "Apple", "Samsung", "Nokia"], answer: 0 },
    { question: "What does SQL stand for?", options: ["Structured Query Language", "Sequential Query Language", "Standard Quick Language", "Systematic Query Logic"], answer: 0 },
    { question: "Which type of malware demands ransom?", options: ["Worm", "Ransomware", "Trojan", "Spyware"], answer: 1 },
    { question: "Which device shows output?", options: ["Keyboard", "Printer", "Mouse", "Scanner"], answer: 1 },
    { question: "Which HTML tag is used for links?", options: ["<a>", "<link>", "<url>", "<href>"], answer: 0 },
    { question: "Which one is a search engine?", options: ["Google", "Facebook", "Twitter", "Instagram"], answer: 0 },
    { question: "Which key is used to refresh a webpage?", options: ["F5", "Ctrl", "Esc", "Tab"], answer: 0 },
    { question: "What is IoT?", options: ["Internet of Things", "Input of Technology", "Information on Time", "Integration of Tools"], answer: 0 },
    { question: "Which company developed Photoshop?", options: ["Adobe", "Corel", "Apple", "Microsoft"], answer: 0 },
    { question: "Which protocol secures websites?", options: ["HTTP", "FTP", "HTTPS", "SMTP"], answer: 2 },
    { question: "What is the shortcut for undo?", options: ["Ctrl + V", "Ctrl + X", "Ctrl + Z", "Ctrl + A"], answer: 2 },
    { question: "What does IP stand for?", options: ["Internet Protocol", "Internal Program", "Information Package", "Interconnected Process"], answer: 0 },
    { question: "Which is NOT an antivirus software?", options: ["Avast", "McAfee", "Photoshop", "Norton"], answer: 2 },
    { question: "What does PDF stand for?", options: ["Public Document File", "Portable Document Format", "Print Data Form", "Personal Data File"], answer: 1 },
    { question: "Which programming language is used for AI?", options: ["Python", "PHP", "HTML", "CSS"], answer: 0 },
    { question: "Which company developed the PlayStation?", options: ["Sony", "Microsoft", "Nintendo", "Sega"], answer: 0 },
    { question: "Which is an example of open-source software?", options: ["Linux", "Windows", "macOS", "MS Office"], answer: 0 },
    { question: "Which shortcut is used for select all?", options: ["Ctrl + A", "Ctrl + S", "Ctrl + P", "Ctrl + L"], answer: 0 },
    { question: "Which one is NOT a web browser?", options: ["Chrome", "Firefox", "Safari", "Excel"], answer: 3 },
    { question: "What does AI stand for?", options: ["Artificial Intelligence", "Automated Input", "Application Interface", "Advanced Integration"], answer: 0 },
    { question: "Which social media platform uses tweets?", options: ["Facebook", "Instagram", "Twitter (X)", "LinkedIn"], answer: 2 },
    { question: "Which company created Alexa?", options: ["Apple", "Amazon", "Microsoft", "Google"], answer: 1 }
  ];

  // DOM references
  const startBtn = document.getElementById('startBtn');
  const quizSection = document.getElementById('quiz');
  const startSection = document.getElementById('start');
  const resultsSection = document.getElementById('results');
  const qTitle = document.getElementById('qTitle');
  const questionEl = document.getElementById('question');
  const optionsEl = document.getElementById('options');
  const feedbackEl = document.getElementById('feedback');
  const submitBtn = document.getElementById('submitBtn');
  const nextBtn = document.getElementById('nextBtn');
  const progressBar = document.getElementById('progressBar');
  const scoreText = document.getElementById('scoreText');
  const detailsEl = document.getElementById('details');
  const restartBtn = document.getElementById('restartBtn');
  const yearEl = document.getElementById('year');

  // state
  let currentQ = 0;
  let score = 0;

  // Show current question
  function loadQuestion() {
    const q = quizData[currentQ];
    qTitle.textContent = `Question ${currentQ + 1} of ${quizData.length}`;
    questionEl.textContent = q.question;

    // clear old
    optionsEl.innerHTML = '';
    feedbackEl.textContent = '';

    // create options safely
    q.options.forEach((opt, idx) => {
      const label = document.createElement('label');
      label.className = 'option';
      label.setAttribute('role', 'radio');

      const input = document.createElement('input');
      input.type = 'radio';
      input.name = 'option';
      input.value = idx;
      input.id = `opt${idx}`;

      const span = document.createElement('span');
      span.textContent = opt;

      label.appendChild(input);
      label.appendChild(span);
      optionsEl.appendChild(label);

      // click on label should focus input — default behavior
    });

    // update controls
    submitBtn.disabled = false;
    nextBtn.disabled = true;

    // update progress (completed)
    const percent = Math.round((currentQ / quizData.length) * 100);
    progressBar.style.width = percent + '%';
  }

  // Start quiz
  startBtn.addEventListener('click', () => {
    startSection.classList.add('hidden');
    quizSection.classList.remove('hidden');
    currentQ = 0;
    score = 0;
    loadQuestion();
    yearEl.textContent = new Date().getFullYear();
  });

  // Submit answer
  submitBtn.addEventListener('click', () => {
    const selected = document.querySelector("input[name='option']:checked");
    if (!selected) {
      feedbackEl.textContent = 'Please select an option.';
      feedbackEl.style.color = '#FF7A7A';
      return;
    }

    const ans = parseInt(selected.value, 10);
    if (ans === quizData[currentQ].answer) {
      feedbackEl.textContent = '✅ Correct!';
      feedbackEl.style.color = '#4ADE80'; // green
      score++;
    } else {
      const correctText = quizData[currentQ].options[quizData[currentQ].answer];
      feedbackEl.textContent = `❌ Wrong — Correct: ${correctText}`;
      feedbackEl.style.color = '#FFB4B4';
    }

    submitBtn.disabled = true;
    nextBtn.disabled = false;
  });

  // Next question
  nextBtn.addEventListener('click', () => {
    currentQ++;
    if (currentQ < quizData.length) {
      loadQuestion();
    } else {
      showResults();
    }
  });

  // Show results
  function showResults() {
    quizSection.classList.add('hidden');
    resultsSection.classList.remove('hidden');
    const wrong = quizData.length - score;
    const percent = Math.round((score / quizData.length) * 100);
    scoreText.textContent = `🎉 Quiz Finished!`;
    detailsEl.innerHTML = `
      ✅ Correct Answers: <strong>${score}</strong><br>
      ❌ Wrong Answers: <strong>${wrong}</strong><br>
      📊 Total Questions: <strong>${quizData.length}</strong><br>
      🏆 Percentage: <strong>${percent}%</strong>
    `;
    yearEl.textContent = new Date().getFullYear();
  }

  // Restart
  restartBtn.addEventListener('click', () => {
    currentQ = 0;
    score = 0;
    resultsSection.classList.add('hidden');
    startSection.classList.remove('hidden');
    progressBar.style.width = '0%';
  });

  // set footer year immediately on load as well
  if (yearEl) yearEl.textContent = new Date().getFullYear();
});
